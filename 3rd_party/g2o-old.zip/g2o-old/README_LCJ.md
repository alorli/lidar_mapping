####################################################################################
### added by lichunjing 2020_07_03
####################################################################################

### 1. 可能需要安装如下依赖项：
```
sudo apt-get install libsuitesparse-dev
sudo apt-get install qtdeclarative5-dev
sudo apt-get install qt5-qmake
sudo apt-get install libqglviewer-dev
```

### 2. 编译安装
```
mkdir build
cd build
cmake ..
make -j8
sudo make install
```






####################################################################################
### 以下是 README.md 中摘出来的重要部分，详细的请参考完成的 README.md 文件
####################################################################################
### Requirements
* cmake             http://www.cmake.org/
* Eigen3            http://eigen.tuxfamily.org

On Ubuntu / Debian these dependencies are resolved by installing the
following packages.
  - cmake
  - libeigen3-dev

#### Optional requirements
* suitesparse       http://www.cise.ufl.edu/research/sparse/SuiteSparse/
* Qt5               http://qt-project.org
* libQGLViewer      http://www.libqglviewer.com/

On Ubuntu / Debian these dependencies are resolved by installing the
following packages.
- libsuitesparse-dev
- qtdeclarative5-dev
- qt5-qmake
- libqglviewer-dev


### Compilation

- `mkdir build`
- `cd build`
- `cmake ../`
- `make`

The binaries will be placed in bin and the libraries in lib which
are both located in the top-level folder.
