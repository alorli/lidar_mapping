// g2o - General Graph Optimization
// Copyright (C) 2011 R. Kuemmerle, G. Grisetti, W. Burgard
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
// * Redistributions of source code must retain the above copyright notice,
//   this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
//   notice, this list of conditions and the following disclaimer in the
//   documentation and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
// IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
// TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
// PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
// TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
// PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
// LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
// NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <iostream>
#include <fstream>
#include <vector>
#include <cmath>

#include <Eigen/Core>
#include <Eigen/StdVector>

#include "g2o/types/slam3d/vertex_se3.h"
#include "g2o/types/slam3d/edge_se3.h"

#include "g2o/stuff/sampler.h"
#include "g2o/stuff/command_args.h"
#include "g2o/core/factory.h"

using namespace std;
using namespace g2o;

int main (int argc, char** argv)
{
  // command line parsing

  //位姿球层数：
  int nodesPerLevel;

  //位姿球圈数：
  int numLaps;

  //位姿球半径：
  double radius;

  //平移变换中添加的噪声
  std::vector<double> noiseTranslation;

  //旋转变换中添加的噪声
  std::vector<double> noiseRotation;

  string outFilename;

  //命令行参数解析功能
  CommandArgs arg;

  // 第一个参数是命令行的选项参数，使用时前面要加 "-"
  // 第二个参数是命令行的选项参数后面跟的参数值保存到的变量
  // 第三个参数是参数默认值
  // 第四个参数是 "-h" help 提示输出信息
  arg.param("o", outFilename, "-", "output filename");
  arg.param("nodesPerLevel", nodesPerLevel, 2, "how many nodes per lap on the sphere");
  arg.param("laps", numLaps, 2, "how many times the robot travels around the sphere");
  arg.param("radius", radius, 10, "radius of the sphere");
  arg.param("noiseTranslation", noiseTranslation, std::vector<double>(), "set the noise level for the translation, separated by semicolons without spaces e.g: \"0.1;0.1;0.1\"");
  arg.param("noiseRotation", noiseRotation, std::vector<double>(), "set the noise level for the rotation, separated by semicolons without spaces e.g: \"0.001;0.001;0.001\"");

  //从命令行中解析参数
  arg.parseArgs(argc, argv);

  //平移变换中添加的噪声：0.01米
  if (noiseTranslation.size() == 0)
  {
    cerr << "using default noise for the translation" << endl;
    noiseTranslation.push_back(0.01);
    noiseTranslation.push_back(0.01);
    noiseTranslation.push_back(0.01);
  }


  cerr << "Noise for the translation:";
  //输出平移中添加的噪声：0.005弧度
  for (size_t i = 0; i < noiseTranslation.size(); ++i)
    cerr << " " << noiseTranslation[i];

  cerr << endl;


  //旋转变换中添加的噪声
  if (noiseRotation.size() == 0)
  {
    cerr << "using default noise for the rotation" << endl;
    noiseRotation.push_back(0.005);
    noiseRotation.push_back(0.005);
    noiseRotation.push_back(0.005);
  }
  cerr << "Noise for the rotation:";

  //输出旋转变换中添加的噪声
  for (size_t i = 0; i < noiseRotation.size(); ++i)
    cerr << " " << noiseRotation[i];

  cerr << endl;


  //3*3 零矩阵
  Eigen::Matrix3d transNoise = Eigen::Matrix3d::Zero();

  // 将噪声量的平方加入到矩阵对角线元素上去
  for (int i = 0; i < 3; ++i)
    transNoise(i, i) = std::pow(noiseTranslation[i], 2);


  //3*3 零矩阵
  Eigen::Matrix3d rotNoise = Eigen::Matrix3d::Zero();

  // 将噪声量的平方加入到矩阵对角线元素上去
  for (int i = 0; i < 3; ++i)
    rotNoise(i, i) = std::pow(noiseRotation[i], 2);



  //double 类型的 6*6信息矩阵，初始值为零矩阵
  Eigen::Matrix<double, 6, 6> information = Eigen::Matrix<double, 6, 6>::Zero();

  //从(0,0)元素开始，向右下数一块3*3矩阵块，将平移噪声矩阵块的逆矩阵填充进去
  information.block<3,3>(0,0) = transNoise.inverse();

  //从(3,3)元素开始，向右下数一块3*3矩阵块，将旋转噪声矩阵块的逆矩阵填充进去
  information.block<3,3>(3,3) = rotNoise.inverse();

  // 打印出的信息矩阵:
  // 10000 0 0 0 0 0
  // 0 10000 0 0 0 0
  // 0 0 10000 0 0 0
  // 0 0 0 40000 0 0
  // 0 0 0 0 40000 0
  // 0 0 0 0 0 40000

  cout << "information matrix:" << endl;
  for(int i=0;i<6;i++)
  {
    for(int j=0;j<6;j++)
    {
      cout << information(i,j) << " ";
    }
    cout << endl;
  }


  //顶点
  vector<VertexSE3*> vertices;

  //里程计边
  vector<EdgeSE3*> odometryEdges;

  //所有边，包括里程计边和闭环边
  vector<EdgeSE3*> edges;


  cout << "numLaps:" << numLaps <<  endl;
  cout << "nodesPerLevel:" << nodesPerLevel <<  endl;

  // return 0;

  //产生50*50=2500个顶点
  int id = 0;

  // 初始顶点：ID=0
  // 添加顶点
  for (int f = 0; f < numLaps; ++f)   //laps：圈
  {
    for (int n = 0; n < nodesPerLevel; ++n)   //Level：层
    {
      //3维的顶点变量
      VertexSE3* v = new VertexSE3;
      v->setId(id++);

      //对内层循环来说，每个rotz是绕z轴旋转，旋转角度为[-pi, pi] 360度范围内分成50等份
      // [-pi+2*pi*0/50.0, -pi+2*pi*1/50.0, -pi+2*pi*2/50.0, -pi+2*pi*3/50.0, -pi+2*pi*4/50.0 ...  -pi+2*pi*49/50.0]
      // 内层循环一个周期，绕z轴旋转一整圈，总共旋转50圈
      Eigen::AngleAxisd rotz(-M_PI + 2*n*M_PI / nodesPerLevel, Eigen::Vector3d::UnitZ());

      // id从0-numLaps * nodesPerLevel增加， id:[0, 49*49]
      // 绕y轴的旋转角度范围为[-90.0, 90.0]也是就[-pi/2.0, pi/2.0],精确来说是[-pi/2.0+pi*1/50*50, -pi/2.0+pi*49*49/50*50]
      // 内层和外层循环总共旋转180度，外观来看，向量(radius, 0, 0)从z轴最下面的点(0, 0, -radius)移动到z轴最上面的点(0, 0, radius)
      Eigen::AngleAxisd roty(-0.5*M_PI + id*M_PI / (numLaps * nodesPerLevel), Eigen::Vector3d::UnitY());

      //换算成旋转矩阵：
      Eigen::Matrix3d rot = (rotz * roty).toRotationMatrix();

      //欧式变换矩阵 Eigen::Isometry3d, 虽然称为3d，实质上是4＊4的矩阵 旋转R+平移T
      Eigen::Isometry3d t;


      t = rot;

      // t.translation()是配置平移部分， t.linear()是取出旋转矩阵部分，结果是3*3矩阵
      // t.translation()保存的是位置点的坐标
      t.translation() = t.linear() * Eigen::Vector3d(radius, 0, 0);

      //设置位姿点，设置位姿点使用的是Eigen::Isometry3d变量，是欧式旋转变换，包括平移部分和旋转部分
      //Pose 点的位置在球表面螺旋上升的轨迹上，方向是该点的球面的法向量
      v->setEstimate(t);

      vertices.push_back(v);
    }
  }



  // //for test added by lichunjing 2018_11_28:
  // // Eigen::Vector3d v_test(1, 0, 0);
  //
  // VertexSE3* v_test = new VertexSE3;
  //
  // v_test->setId(0);
  //
  // Eigen::AngleAxisd rotz_test(0.0, Eigen::Vector3d::UnitZ());
  //
  // Eigen::Matrix3d rot_test_pre = rotz_test.toRotationMatrix();
  // Eigen::Matrix3d rot_test_cur = rotz_test.toRotationMatrix();
  //
  // Eigen::Isometry3d t_test_pre = rot_test_pre;
  // Eigen::Isometry3d t_test_cur = rot_test_cur;
  //
  // // t.translation()是取出平移部分， t.linear()是取出旋转矩阵部分，结果是3*3矩阵
  // t_test_pre.translation() = t_test_pre.linear() * Eigen::Vector3d(2.0, 0, 0);
  // t_test_cur.translation() = t_test_cur.linear() * Eigen::Vector3d(-1.0, 0, 0);
  //
  //
  //
  // //欧式变换矩阵 Eigen::Isometry3d, 虽然称为3d，实质上是4＊4的矩阵 旋转R+平移T
  // //在顶点中取出一个欧式变换：
  //
  // //在所有顶点中提取前后相邻的两个顶点
  // VertexSE3* vertices_pre = vertices[0];
  // VertexSE3* vertices_cur  = vertices[1];
  //
  // Eigen::Isometry3d test = vertices_pre->estimate() * vertices_cur->estimate();
  //
  // // cout << "prev->estimate():" << prev->estimate() <<  endl;
  //
  // return 0;

  // generate odometry edges
  // 生成里程计的边
  for (size_t i = 1; i < vertices.size(); ++i)
  {
    //在所有顶点中提取前后相邻的两个顶点
    VertexSE3* prev = vertices[i-1];
    VertexSE3* cur  = vertices[i];

    // TODO: why?
    Eigen::Isometry3d t = prev->estimate().inverse() * cur->estimate();

    //边
    EdgeSE3* e = new EdgeSE3;

    //设置顶点ID
    e->setVertex(0, prev);
    e->setVertex(1, cur);

    //设置观测量
    e->setMeasurement(t);

    //设置信息矩阵
    e->setInformation(information);

    odometryEdges.push_back(e);
    edges.push_back(e);
  }

  // generate loop closure edges
  // 生成闭环边
  for (int f = 1; f < numLaps; ++f)
  {
    for (int nn = 0; nn < nodesPerLevel; ++nn)
    {
      //循环初始时:from = vertices[0]
      //内层第一次循环时：f=1，   from = vertices[0]，vertices[1]，vertices[2],.....vertices[49]
      //内层第二次循环时：f=2，   from = vertices[50+0]，vertices[50+1]，vertices[50+2],.....vertices[50+49]
      //内层第三次循环时：f=3，   from = vertices[50*2+0]，vertices[50*2+1]，vertices[50*2+2],.....vertices[50*2+49]
      //.....
      //内层第49次循环时：f=49，   from = vertices[50*2+0]，vertices[50*2+1]，vertices[50*2+2],.....vertices[50*2+49]
      VertexSE3* from = vertices[(f-1)*nodesPerLevel + nn];

      //3次循环：
      //第1次循环：n = -1
      //第2次循环：n = 0
      //第3次循环：n = 1
      for (int n = -1; n <= 1; ++n)
      {
        //如果 f=49，将没有下一条边
        //如果 n=1：？？
        if (f == numLaps-1 && n == 1)
          continue;

        //每一个点都找上层的对应点以及对应点的前后两个点建立闭环边：
        //循环初始时:  to = vertices[49]
        //内层第一次循环时：f=1, nn=0，n=-1,0,1    to = vertices[49]，vertices[50]，vertices[51]
        //内层第二次循环时：f=1, nn=1，n=-1,0,1    to = vertices[51]，vertices[52]，vertices[53]
        //内层第三次循环时：f=1, nn=2，n=-1,0,1    to = vertices[50]，vertices[53]，vertices[54]
        //.....
        //内层第49次循环时：f=1，nn=49,n=-1,0,1   from = vertices[50+49-1]，vertices[50+49]，vertices[50+49+1]
        VertexSE3* to   = vertices[f*nodesPerLevel + nn + n];

        //闭环边的欧式变换：
        Eigen::Isometry3d t = from->estimate().inverse() * to->estimate();

        EdgeSE3* e = new EdgeSE3;

        e->setVertex(0, from);
        e->setVertex(1, to);

        //设置闭环边的观测量
        e->setMeasurement(t);

        //设置闭环边的信息矩阵
        e->setInformation(information);

        edges.push_back(e);
      }
    }
  }


  //transNoise 是 3*3 平移变换的噪声矩阵，是对角矩阵
  GaussianSampler<Eigen::Vector3d, Eigen::Matrix3d> transSampler;
  transSampler.setDistribution(transNoise);

  GaussianSampler<Eigen::Vector3d, Eigen::Matrix3d> rotSampler;
  rotSampler.setDistribution(rotNoise);

  // noise for all the edges
  //在所有的边里面都添加了随机噪声：
  for (size_t i = 0; i < edges.size(); ++i)
  {
    EdgeSE3* e = edges[i];

    //e->measurement().linear()是边对应的欧式变换的旋转部分，(Eigen::Quaterniond)表示强制类型转换，将旋转部分转换成四元数：
    Eigen::Quaterniond gtQuat = (Eigen::Quaterniond)e->measurement().linear();

    //e->measurement().translation()是边对应的欧式变换的平移部分：
    Eigen::Vector3d gtTrans = e->measurement().translation();

    //产生一个3维的噪声向量
    Eigen::Vector3d quatXYZ = rotSampler.generateSample();

    //norm()是向量的范数，是各向量分量的平方和
    //quatXYZ的三个分量是四元数的虚部，1.0 - quatXYZ.norm()就是四元数的实部，以此来构造一个随机的旋转四元数
    double qw = 1.0 - quatXYZ.norm();

    if (qw < 0)
    {
      qw = 0.;
      cerr << "x";
    }

    //注意：Eigen::Quaterniond的构造函数的传参顺序为：wxyz，注意第一个参数是w
    Eigen::Quaterniond rot(qw, quatXYZ.x(), quatXYZ.y(), quatXYZ.z());

    //四元数归一化
    rot.normalize();

    //产生平移噪声
    Eigen::Vector3d trans = transSampler.generateSample();

    //gtQuat是模型中精确的四元数，rot是噪声四元数，相乘就是在模型中添加四元数噪声
    rot = gtQuat * rot;

    //gtTrans是模型中精确地平移部分，叠加上平移噪声
    trans = gtTrans + trans;

    //带噪声的观测量
    Eigen::Isometry3d noisyMeasurement = (Eigen::Isometry3d) rot;
    noisyMeasurement.translation() = trans;

    //e是edges元素的指针，这里操作的是变量容器中的元素值
    e->setMeasurement(noisyMeasurement);
  }


  // concatenate(vt. 连结；使连锁) all the odometry constraints to compute the initial state
  // 根据所有里程计边的约束，计算初始姿态
  for (size_t i = 0; i < odometryEdges.size(); ++i)
  {
    //前一部分是里程计边，所以这里取的是里程计边：
    EdgeSE3* e = edges[i];

    //从前往后依次连接里程计边
    VertexSE3* from = static_cast<VertexSE3*>(e->vertex(0));  //里程计边的第一个顶点
    VertexSE3* to = static_cast<VertexSE3*>(e->vertex(1));    //里程计边的第二个顶点

    //超图
    HyperGraph::VertexSet aux;

    aux.insert(from);

    //计算初始估计状态：
    e->initialEstimate(aux, to);
  }




  // write output，写文件输出
  ofstream fileOutputStream;

  if (outFilename != "-")
  {
    cerr << "Writing into " << outFilename << endl;

    fileOutputStream.open(outFilename.c_str());
  }
  else
  {
    cerr << "writing to stdout" << endl;
  }

  //获取顶点标签
  string vertexTag = Factory::instance()->tag(vertices[0]);

  //获取边标签
  string edgeTag = Factory::instance()->tag(edges[0]);

  ostream& fout = outFilename != "-" ? fileOutputStream : cout;

  //写顶点到文件
  for (size_t i = 0; i < vertices.size(); ++i)
  {
    VertexSE3* v = vertices[i];
    fout << vertexTag << " " << v->id() << " ";
    v->write(fout);
    fout << endl;
  }

  //写边到文件
  for (size_t i = 0; i < edges.size(); ++i)
  {
    EdgeSE3* e = edges[i];

    VertexSE3* from = static_cast<VertexSE3*>(e->vertex(0));
    VertexSE3* to = static_cast<VertexSE3*>(e->vertex(1));

    fout << edgeTag << " " << from->id() << " " << to->id() << " ";
    e->write(fout);
    fout << endl;
  }

  return 0;
}
